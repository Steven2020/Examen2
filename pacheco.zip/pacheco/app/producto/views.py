from django.shortcuts import render
from django.shortcuts import redirect
from django.http import HttpResponse
from .forms import FormularioProducto
from app.modelo.models import Producto
from django.contrib.auth.decorators import login_required


def principal(request):
    lista = Producto.objects.all()
    context = {
    'lista':lista,
    }
    return render(request,'producto/principal_producto.html', context)


def crear(request):
    formulario = FormularioProducto(request.POST)
    if request.method == "POST":
        if formulario.is_valid():
            datos = formulario.cleaned_data
            producto = Producto()
            producto.idProducto = datos.get('idProducto')
            producto.nombreProducto = datos.get('nombreProducto')
            producto.descripcion = datos.get('descripcion')
            producto.precioUnitario = datos.get('precioUnitario')
            producto.cantidad = datos.get('cantidad')
            producto.save()
            return redirect(principal)
    context = {
        'f': formulario
    }
    return render(request, 'producto/crear_producto.html', context)


def modificar(request):
	id = request.GET['idProducto']
	producto = Producto.objects.get(idProducto = id)
	if request.method == 'POST':
		formulario = FormularioProducto(request.POST, instance = producto)
		if formulario.is_valid():
			datos = formulario.cleaned_data
			producto.nombreProducto = datos.get('nombreProducto')
			producto.descripcion = datos.get('descripcion')
			producto.precioUnitario = datos.get('precioUnitario')
			producto.save()
			return redirect(principal)
	else:
		formulario = FormularioProducto(instance = producto)
	context = {
		'f' : formulario
	}
	return render(request, 'producto/modificar_producto.html', context)
