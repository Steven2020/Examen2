from django.contrib import admin
from .models import Producto

class AdminProducto(admin.ModelAdmin):
	list_display = ["idProducto","nombreProducto","descripcion","precioUnitario","cantidad"]
	list_editable = ["nombreProducto","descripcion","precioUnitario"]
	list_filter = ["idProducto","precioUnitario","cantidad"]
	search_fiels = ["idProducto","nombreProducto"]

	class Meta:
		model = Producto

admin.site.register(Producto, AdminProducto)
