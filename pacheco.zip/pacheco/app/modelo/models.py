from django.db import models

class Producto(models.Model):
	idProducto = models.CharField('Identificador Producto',max_length=10,unique=True)
	nombreProducto = models.CharField('Nombre Producto',max_length=30, blank=False, null=False)
	descripcion = models.CharField('Descripcion',max_length=30, blank=False, null=False)
	precioUnitario = models.CharField('Precio Unitario',max_length=25,blank=False,null=False)
	cantidad = models.DecimalField(max_digits=6, decimal_places=2)
	#fechaIngreso = models.DateTimeField(auto_now_add=True)

	def getNombresCompletos(self):
		cadena = '{0} {1} {2}'
		return cadena.format(self.idProducto, self.nombreProducto, self.cantidad)

	def __str__(self):
		return self.idProducto
